#!/usr/bin/python3

# Run me like this:
# $ python3 padding_oracle.py "https://cryptoproject.gtinfosec.org/GTusername/paddingoracle/verify" "5a7793d3..."
# or select "Padding Oracle" from the VS Code debugger

import json
import sys
import time
from typing import Union, Dict, List
import copy

import requests

# Create one session for each oracle request to share. This allows the
# underlying connection to be re-used, which speeds up subsequent requests!
s = requests.session()


def oracle(url: str, messages: List[bytes]) -> List[Dict[str, str]]:
    while True:
        try:
            r = s.post(url, data={"message": [m.hex() for m in messages]})
            r.raise_for_status()
            return r.json()
        # Under heavy server load, your request might time out. If this happens,
        # the function will automatically retry in 10 seconds for you.
        except requests.exceptions.RequestException as e:
            sys.stderr.write(str(e))
            sys.stderr.write("\nRetrying in 10 seconds...\n")
            time.sleep(10)
            continue
        except json.JSONDecodeError as e:
            sys.stderr.write("It's possible that the oracle server is overloaded right now, or that provided URL is wrong.\n")
            sys.stderr.write("If this keeps happening, check the URL. Perhaps your GTusername is not set.\n")
            sys.stderr.write("Retrying in 10 seconds...\n\n")
            time.sleep(10)
            continue


def main():
    if len(sys.argv) != 3:
        print(len(sys.argv))
        print(f"usage: {sys.argv[0]} ORACLE_URL CIPHERTEXT_HEX", file=sys.stderr)
        sys.exit(-1)
    oracle_url, message = sys.argv[1], bytes.fromhex(sys.argv[2])

    if oracle(oracle_url, [message])[0]["status"] != "valid":
        print("Message invalid", file=sys.stderr)

    message_array = bytearray(message)
    # message_array[-1] = message_array[-1] + 1
    padding_finder_array = [0 for i in range(len(message_array))]
    for i in range(len(message_array)):
        modified_message = copy.deepcopy(message_array)
        modified_message[-1*i - 1] = (modified_message[-1*i - 1] + 1) % 256
        padding_finder_array[i] = modified_message
    padding_finder = oracle(oracle_url, padding_finder_array)
    num_padding = 0
    while(padding_finder[num_padding + 16]['status'] == 'invalid_padding'):
        num_padding = num_padding + 1
    
    orig_num_padding = num_padding


    decrypted = bytearray(len(message_array) - 16)
    for i in range(num_padding):
        decrypt_index = -1 * i - 1
        encrypt_index = decrypt_index - 16
        # print(message_array[encrypt_index])
        decrypted[decrypt_index] = message_array[encrypt_index] ^ num_padding

    print(decrypted)
    truncated_decrypted = decrypted
    truncated_message = message_array
    count = 0
    while len(truncated_decrypted) > 0:
        while num_padding < 16:
            mask_length = num_padding
            num_padding += 1
            print("mask_length")
            print(mask_length)
            mask = 0
            for i in range(mask_length):
                mask *= 256
                mask += num_padding
            print(mask.to_bytes((mask.bit_length() + 7) // 8, byteorder='big'))
            bytes_to_modify = mask ^ int.from_bytes(bytes(truncated_decrypted[-1 * mask_length:]), "big") # need to account for trunction
            brute_force_array = []
            for i in range(256):
                copy_array = copy.deepcopy(truncated_message)
                if mask_length > 0:
                    copy_array = copy_array[0:-16-mask_length] + bytearray(bytes_to_modify.to_bytes((mask.bit_length() + 7) // 8, byteorder='big')) + copy_array[-16:]
                copy_array[-16-mask_length-1] = i
                brute_force_array.append(copy_array)
            brute_force_finder = oracle(oracle_url, brute_force_array)
            brute_force_value = 0
            while(brute_force_finder[brute_force_value]['status'] == 'invalid_padding'):
                brute_force_value += 1
            print("Success!")
            print(brute_force_value)
            brute_force_value = brute_force_value ^ num_padding
            truncated_decrypted[-1*mask_length - 1] = brute_force_value # need to account for truncation
            decrypted[-1*mask_length - 1 - 16 * count] = brute_force_value
        truncated_message = truncated_message[0:-16]
        truncated_decrypted = truncated_decrypted[0:-16]
        num_padding = 0
        count += 1
        # brute_force_value.to_bytes(1,'big') + 
    message_array = message_array[0:-16]
    plaintext = bytearray()
    for byte1, byte2 in zip(message_array, decrypted):
        plaintext.append(byte1 ^ byte2)
    
    
    plaintext = plaintext[0:-1 * (orig_num_padding + 32)]
    result = plaintext.decode('utf-8')
    print(result)


if __name__ == '__main__':
    main()
