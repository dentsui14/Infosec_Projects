#!/usr/bin/python3

# Run me like this:
# $ python3 bleichenbacher.py “from_username+to_username+100.00”
# or select "Bleichenbacher" from the VS Code debugger

from roots import *

import hashlib
import sys


def main():
    if len(sys.argv) < 2:
        print(f"usage: {sys.argv[0]} MESSAGE", file=sys.stderr)
        sys.exit(-1)
    message = sys.argv[1]

    #
    # TODO: Forge a signature
    #
    message_bytes = message.encode('utf-8')
    sha256_digest = hashlib.sha256(message_bytes).hexdigest()
    forged_signature = 0
    val = b'\x00\x01\xff\x00\x30\x31\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x01\x05\x00\x04\x20' + bytes.fromhex(sha256_digest) + b'\x00' * 201
    forged_signature = int.from_bytes(val,byteorder='big')
    forged_signature = integer_nthroot(forged_signature,3)
    if forged_signature[1] == False:
        forged_signature = forged_signature[0] + 1
    else:
        forged_signature = forged_signature[0]
    print(bytes_to_base64(integer_to_bytes(forged_signature, 256)))


if __name__ == '__main__':
    main()
