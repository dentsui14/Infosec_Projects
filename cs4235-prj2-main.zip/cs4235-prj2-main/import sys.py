import sys
from urllib.parse import quote
from pysha256 import sha256, padding

hex_string = "0294f72b2d585c91ad370852bbcc2816d97a82752068103fccb6d17dee9f5484"
byte_array = bytes.fromhex(hex_string)
print(byte_array)