import re
input = "<<bodybody onload=alert(0)>"
filtered = re.sub(r"(?i)script|<img|<body|<style|<meta|<embed|<object", "", input)
print(filtered)