# 2078912830
# b'{\xe9\xb1>'
from hashlib import md5
target = "'=0#"
target = target.encode('latin-1', errors='ignore').decode('latin-1')
guess = 0
while True:
    guess_bytes = guess.to_bytes((guess.bit_length() + 7) // 8, byteorder='big')
    guess_string = bytes.fromhex(md5(guess_bytes).hexdigest()).decode('latin-1')
    if target in guess_string and guess != 161533998 and guess != 234211683:
        print(guess_bytes.decode('latin-1'))
        break
    guess += 1
